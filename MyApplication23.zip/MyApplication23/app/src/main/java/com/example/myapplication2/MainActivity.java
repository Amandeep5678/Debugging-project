package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
ListView lisv;
ListAdapter listAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lisv= findViewById(R.id.ListView);
        String apiurl = getResources().getString(R.string.repourl);
        lisv.setAdapter(listAdapter);

    }
    public ArrayList<Repo> getData(String url){
        ArrayList<Repo> repoArrayList= new ArrayList<>();
        try {
            String jsondata = new  AsyncData().execute(url).get();
            JSONObject mainobj = new JSONObject(jsondata);
            JSONArray repoArray = mainobj.getJSONArray("name");

            for(int i=0; i<repoArray.length();i++){
                JSONObject childobj = repoArray.getJSONObject(i);
                 String repository =childobj.getString("Repository");
                 String owner = childobj.getString("Owner") ;
                 repoArrayList.add (new Repo(repository,owner));
            }
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }
        catch (ExecutionException e){
            e.printStackTrace();
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        System.out.println("Size of arraylist(Outside try):"+repoArrayList.size());
        return  repoArrayList;
    }
}