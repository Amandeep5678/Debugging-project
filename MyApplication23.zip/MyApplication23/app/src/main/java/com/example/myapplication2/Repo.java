package com.example.myapplication2;

public class Repo {
    private String repository;
    private String owner;



    public Repo( String repository, String owner) {
        this.owner= owner;
        this.repository = repository;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(String repository) {
        this.repository = repository;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }
}
